import fs from "node:fs";

const manifest = "android/app/src/main/AndroidManifest.xml";
if (!fs.existsSync(manifest)) {
  throw new Error("AndroidManifest.xml not found. Run `npx cap add android` first.");
}
let xml = fs.readFileSync(manifest, "utf8");
const permissions = [
  '    <uses-permission android:name="android.permission.INTERNET" />',
  '    <uses-permission android:name="android.permission.RECORD_AUDIO" />',
  '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '    <uses-permission android:name="android.permission.VIBRATE" />'
];
for (const permission of permissions) {
  const name = permission.match(/android:name="([^"]+)"/)[1];
  if (!xml.includes(name)) {
    xml = xml.replace(/<application\b/, permission + "\n    <application");
  }
}
fs.writeFileSync(manifest, xml);
console.log("Android permissions added.");
